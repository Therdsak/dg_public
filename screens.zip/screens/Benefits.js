import React, { Component } from 'react';
import {ScrollView, SafeAreaView, StyleSheet, TouchableOpacity, View, Text, Dimensions} from 'react-native';
import Icon from 'react-native-vector-icons/Entypo';

export default class Benefits extends Component {
    state = {
        benefits: require('../database/benefits.json'),
    }
    
    showBenefit = (item) => {
        this.props.navigation.navigate('BenefitDetail', item);
    }
    
    render() {
        const styles = StyleSheet.create({
            container: {
                padding: 15,
                borderBottomWidth: 1.5,
                borderBottomColor: '#E9E9E9',
                backgroundColor: '#FFFFFF',
            },
            list: {
                flex: 1,
                flexDirection: 'row', 
                justifyContent: 'center',
            },
            text: {
                color: '#000000',
                fontFamily: 'Prompt-Regular',
                fontSize: 16,
                width: Math.round(Dimensions.get('window').width)-(30+18),
            }
        })

        return (
            <ScrollView style={{backgroundColor: '#F5F3F6'}}>
                <SafeAreaView style={{flex: 1, flexDirection: 'column'}}>
                    {
                    this.state.benefits.map((item, index) => (
                        <TouchableOpacity key={index} style={styles.container} onPress = {() => this.showBenefit(item)}>
                            <View style={styles.list}>
                                <Text style={styles.text}>
                                    {item.title}
                                </Text>
                                <View style={{width: 18, alignItems: 'flex-end'}}>
                                    <Icon name='chevron-right' size={18} color="#000000" />
                                </View>
                            </View>
                        </TouchableOpacity>
                    ))
                    }
                </SafeAreaView>
            </ScrollView>
        );
  }
}
