import React, {Component} from 'react';
import {SafeAreaView, StyleSheet, TouchableOpacity, ImageBackground, ActivityIndicator, View, Image, Text} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import {getBottomSpace} from 'react-native-iphone-x-helper'

import CardRegister from './Card/Register';
import DigitalCard from './Card/Detail';
import Benefits from './Benefits';
import BenefitDetail from './BenefitDetail';
import LoanApplication from './LoanApplication';
import CallCenter from './CallCenter';
import Location from './Location';

import {createAppContainer} from 'react-navigation';
import {createStackNavigator} from 'react-navigation-stack';
import {createBottomTabNavigator} from 'react-navigation-tabs';

import {fromLeft} from 'react-navigation-transitions';

const handleCustomTransition = ({ scenes }) => {
    const prevScene = scenes[scenes.length - 2];
    const nextScene = scenes[scenes.length - 1];

    if (prevScene
      && prevScene.route.routeName === 'Benefit'
      && nextScene.route.routeName === 'BenefitDetail') {
      return fromLeft();
    }
}

const Card = createStackNavigator({
  DigitalCard: {
      screen: DigitalCard,
      navigationOptions: () => ({
          headerTruncatedBackTitle: '', 
          headerShown: false,
      }),
  },
  Benefit: {
      screen: Benefits,
      navigationOptions: () => ({
          title: 'สิทธิประโยชน์',
          headerTruncatedBackTitle: '', 
          headerTintColor: '#B91E67',
          headerTitleStyle: {
              backgroundColor: '#FCFCFC',
              fontFamily: 'Prompt-Medium',
              fontSize: 18, 
              color: '#B91E67'
          },
      }),
  }, 
  BenefitDetail: {
      screen: BenefitDetail,
      navigationOptions: () => ({
          headerTruncatedBackTitle: '', 
          headerTintColor: '#B91E67',
          headerTitleStyle: {
              backgroundColor: '#FCFCFC',
              fontFamily: 'Prompt-Medium',
              fontSize: 18, 
              color: '#B91E67'
          },
      }),
  },
  LoanApplication: {
      screen: LoanApplication,
      navigationOptions: () => ({
          title: 'แบบคำขอกู้ยืมเงิน',
          headerTruncatedBackTitle: '', 
          headerTintColor: '#B91E67',
          headerTitleStyle: {
              backgroundColor: '#FCFCFC',
              fontFamily: 'Prompt-Medium',
              fontSize: 18, 
              color: '#B91E67'
          },
      }),
  }, 
}, {
  initialRouteName: 'DigitalCard',
  transitionConfig: (nav) => handleCustomTransition(nav)
});

const screens = {
  CardRegister: {
    screen: CardRegister,
    navigationOptions: {
      tabBarVisible: false
    },
  },  
  Card: {
      screen: Card,
      navigationOptions: {
        tabBarLabel: 'ดูข้อมูล',
        tabBarIcon:  (
              <Image source={{uri: 'icon_profile'}} style={{width: 28, height: 28}} />
        )
      },
  },
  CallCenter: {
      screen: CallCenter,
      navigationOptions: {
        tabBarLabel: 'สายด่วน',
        tabBarIcon:  (
              <Image source={{uri: 'icon_call'}} style={{width: 28, height: 28}} />
        )
      },
  },
  Location: {
      screen: Location,
      navigationOptions: {
        tabBarLabel: 'ค้นหาศูนย์\nใกล้ที่สุด',
        tabBarIcon:  (
              <Image source={{uri: 'icon_location'}} style={{width: 28, height: 28}} />
        )
      },
  },
}

const TabBar = props => {
  const {
    renderIcon,
    getLabelText,
    activeTintColor,
    inactiveTintColor,
    onTabPress,
    onTabLongPress,
    getAccessibilityLabel,
    navigation
  } = props;

  const { routes, index: activeRouteIndex } = navigation.state;

  return (
    <View style={[tabStyles.container]}>
    {routes.map((route, routeIndex) => {
      if(route.routeName!='CardRegister'){
        const isRouteActive = routeIndex === activeRouteIndex;
        const tintColor = isRouteActive ? activeTintColor : inactiveTintColor;
        return (
          <TouchableOpacity
            key={routeIndex}
            style={[tabStyles.tabButton, routeIndex>0 ? {borderLeftWidth: 1, borderColor: '#E1E1E1'} : '']}
            onPress={() => {
              onTabPress({ route });
            }}
            onLongPress={() => {
              onTabLongPress({ route });
            }}
            accessibilityLabel={getAccessibilityLabel({ route })}
          >
            {renderIcon({ route, focused: isRouteActive, tintColor })}
            <Text style={[route.routeName!='Location' ? tabStyles.text : tabStyles.textSmall , {color: tintColor}]}>{getLabelText({ route })}</Text>
          </TouchableOpacity>
        );
      }
    })}
    </View>
  );
};

const tabStyles = StyleSheet.create({
  container: {
    flexDirection: "row",
    backgroundColor: '#FCFCFC', 
    elevation: 2,
    height: 55,
    marginBottom: getBottomSpace()/2,
  },
  tabButton: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  text: {
    marginLeft: 5,
    fontFamily: 'Prompt-Regular',
    fontSize: 14,
  },
  textSmall: {
    marginLeft: 5,
    fontFamily: 'Prompt-Regular',
    fontSize: 14,
  },
});

export default class Navigation extends Component {
  constructor(props) {
      super(props);
      this.state = {
          loggin: 'loading'
      };
  }

  async componentDidMount() {
    let value = await AsyncStorage.getItem('cardDetail');
    global.cardDetail = JSON.parse(value);
    if (global.cardDetail != null && global.cardDetail.NID.length==13){
      this.setState({loggin: 'logged'});
    }else{
      this.setState({loggin: 'none'});
    }
  }

  render(){
      if(this.state.loggin=='none' || this.state.loggin=='logged'){
        const MainMenu = createAppContainer(createBottomTabNavigator(screens, {
          headerMode: 'none',
          initialRouteName: this.state.loggin=='none' ? 'CardRegister' : 'Card', 
          tabBarComponent: TabBar,
          tabBarOptions: {
            showIcon: true,
            activeTintColor: '#000000',
            inactiveTintColor: '#000000',
          }
        }));
        return (<MainMenu />);
      }else{
        return (
          <ImageBackground source={{uri: 'background'}} style={{width: '100%', height: '100%'}}>
            <SafeAreaView style={{flex: 1, flexDirection: 'column', justifyContent: 'space-between', alignItems: 'center', elevation: 2}}>
              <View style={{justifyContent: 'center', alignItems: 'center', height: 108, marginTop: 22, marginBottom: 22}}>
                  <Image source={{uri: 'egov_text_logo'}} style={{width: 145, height: 108}}/>
              </View>
              <View style={{flex:1, justifyContent: 'center', alignItems: 'center'}}>
                  <ActivityIndicator></ActivityIndicator>
              </View>
            </SafeAreaView>
          </ImageBackground>
        );
      }
  }
}