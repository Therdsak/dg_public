import React, {Component} from 'react';
import {SafeAreaView, ScrollView, ImageBackground, Image, StyleSheet, TouchableOpacity, TouchableWithoutFeedback, View, Text, Dimensions} from 'react-native';
import QRCode from 'react-native-qrcode-svg';
import Barcode from 'react-native-barcode-builder';
import Modal from "react-native-modal";

export default class DigitalCard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isCardVisible: false, 
      screenWidth: Math.round(Dimensions.get('window').width)*0.9,
      cardRatio: 1,
    };
  }
  
  idFormat = (str, split=true) => {
    if(str!=null){
      let cleaned = str.replace(/\D/g, '');
      let match = cleaned.match(/^(\d{1})(\d{4})(\d{5})(\d{2})(\d{1})$/);
      let splitItem = '-';
      if(!split){
        splitItem = ' ';
      }
      if (match) {
        return match[1] + splitItem + match[2] + splitItem + match[3] + splitItem + match[4] + splitItem + match[5];
      }else{
        return str;
      }
    }
  };

  nameFormat = (str, type) => {
    if(str!=null){
      let nameArr = str.split(' ');
      if(type==1){
        let name = nameArr[0]+' ';
        name += nameArr[1];
        return name;
      }else{
        let lastname = '';
        for(let i=2; i<nameArr.length; i++){
          lastname += nameArr[i]+' ';
        }
        return lastname;
      }
    }
  };

  normalDateFormat = (str, lang='th') => {
    if(str!=null){
      let dateArr = str.split('-');
      let dateStatus = false;
      let dateText = '';
      const monthsTh = [ "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน", "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"];
      const monthsEn = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
      if(parseInt(dateArr[0])){
        dateStatus = true;
        dateText += parseInt(dateArr[0]) + ' ';
      }else{
        dateText += '-' + ' ';
      }
      if(parseInt(dateArr[1])){
        dateStatus = true;
        if(lang=='th'){
          dateText += monthsTh[parseInt(dateArr[1])-1] + ' ';
        }else{
          dateText += monthsEn[parseInt(dateArr[1])-1] + '. ';
        }
      }else{
        dateText += '-' + ' ';
      }
      if(parseInt(dateArr[2])){
        dateStatus = true;
        if(lang=='th'){
          dateText += parseInt(dateArr[2])+ ' ';
        }else{
          dateText += (parseInt(dateArr[2])-543) + ' ';
        }
      }else{
        dateText += '-' + ' ';
      }
      return  dateStatus ? dateText : lang=='th' ? 'ตลอดชีพ' : 'LIFELONG';
    }
  };

  shortDateFormat = (str, lang='th') => {
    if(str!=null){
      if(str != 'ตลอดชีพ'){
        let dateArr = str.split('-');
        const monthsTh = ["ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."];
        const monthsEn = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
        if(lang=='th'){
          return parseInt(dateArr[0]) + ' ' + monthsTh[parseInt(dateArr[1])-1] + ' ' + dateArr[2];
        }else{
          return parseInt(dateArr[0]) + ' ' + monthsEn[parseInt(dateArr[1])-1] + '. ' + (parseInt(dateArr[2])-543);
        }
      }else{
        return lang=='th' ? 'ตลอดชีพ' : 'LIFELONG';
      }
    }
  };
  
  closeCard = () => {
    this.setState({ isCardVisible: !this.state.isCardVisible });
  }

  onLayout = () => {
    let width = Math.round(Dimensions.get('window').width);
    let height = Math.round(Dimensions.get('window').height);
    if(global.cardDetail.CTYPE=='Card'){
      if(height/2>width){
        width = width*0.88;
      }
      if(width/2>height){
        width = width*0.75;
        height = height*0.75;
      }
    }else{
      if(height/2>width){
        width = width*0.88;
      }
      if(width/2>height){
        width = width*0.8;
        height = height*0.8;
      }
    }
    this.setState({
      screenWidth: height>width ? (width*0.9) : ((width+120)*0.627),
      cardRatio: height>width ? 1 : ((width+120)/height)*0.627,
    });
  }

  render(){  

    let cardShow;

    if(global.cardDetail.CTYPE=='Card'){
      const card = StyleSheet.create({
        container: {
          flexDirection: 'column', 
          width: '100%',
          borderRadius: 15, 
        }, 
        firstSection: {
          flexDirection: 'row',
        }, 
        profileDetail: {
          flex: 1, 
          flexDirection: 'column', 
          marginLeft: 5*this.state.cardRatio, 
        },
        photo: {
          overflow: 'hidden', 
          justifyContent: 'center', 
          alignItems: 'center', 
          width: 80*this.state.cardRatio, 
          height: 96*this.state.cardRatio, 
        }, 
        photoImage: {
          width: 80*this.state.cardRatio, 
          height: 96*this.state.cardRatio, 
        }, 
        header: {
          justifyContent: 'center', 
          alignItems: 'center', 
        },
        title: {
          fontFamily: 'THSarabunNew-Bold', 
          fontWeight: 'bold', 
          fontSize: 12*this.state.cardRatio,
        },
        titlePwd: {
          fontWeight: 'bold', 
          color: '#b72b69', 
        }, 
        id: {
          marginBottom: 5*this.state.cardRatio, 
          fontSize: 14*this.state.cardRatio, 
          fontFamily: 'THSarabunNew-Bold', 
          fontWeight: 'bold', 
        },
        label: {
          fontFamily: 'THSarabunNew-Bold',
          fontSize: 14*this.state.cardRatio, 
          marginTop: -5*this.state.cardRatio,
        }, 
        text: {
          fontSize: 12*this.state.cardRatio, 
          fontFamily: 'THSarabunNew-Bold',
          fontWeight: 'bold', 
          marginTop: -5*this.state.cardRatio,
        }, 
        deform:{
          justifyContent: 'center', 
          alignItems: 'center', 
          marginTop: -15*this.state.cardRatio,
        }, 
        address: {
          flexDirection: 'row', 
          marginTop: 10*this.state.cardRatio, 
          marginBottom: 10*this.state.cardRatio, 
        },
        addressText: {
          marginLeft: 10*this.state.cardRatio,
          width: '55%', 
        },
        date: {
          flexDirection: 'column', 
          justifyContent: 'center', 
          alignItems: 'center', 
          width: '30%'
        }, 
        lastestSection: {
          flexDirection: 'row',
        },
      });
      cardShow = (
        <View style={{justifyContent:'center', flexDirection: this.state.cardRatio==1 ? 'column' : 'row', alignItems: 'center'}}>
          <View onLayout={this.onLayout} style={{width:this.state.screenWidth}}>
            <ImageBackground source={{uri: 'watermark'}} imageStyle={{borderRadius: 15}}style={{padding: 10*this.state.cardRatio}}>
              <View style={card.container}>
                <View style={card.firstSection}>
                  <View style={card.photo}>
                    <Image style={card.photoImage} source={{uri: cardDetail.IMAGE_DATA}} />
                  </View>
                  <View style={card.profileDetail}>
                    <View style={card.header}>
                      <Text numberOfLines={1} style={card.title}>บัตรประจำตัวคนพิการ ID Card for <Text style={card.titlePwd}>PWD</Text></Text>
                      <Text style={card.id}>{this.idFormat(cardDetail.NID)}</Text>
                    </View>
                    <Text style={card.label}>ชื่อ  <Text style={card.text}>{this.nameFormat(cardDetail.PERSON_NAME, 1)}</Text></Text>
                    <Text style={card.label}>นามสกุล  <Text style={card.text}>{this.nameFormat(cardDetail.PERSON_NAME, 2)}</Text></Text>
                    <Text style={card.label}>วัน-เดือน-ปี เกิด  <Text style={card.text}>{this.normalDateFormat(cardDetail.BIRTH_DATE)}</Text></Text>
                    <Text style={card.label}>ประเภทความพิการ</Text>
                    <View style={card.deform}>
                      <Text style={card.text}>{cardDetail.DEFORM_ID}</Text>
                      <Text style={card.text}>{cardDetail.DEFORM_NAME}</Text>
                    </View>
                  </View>
                </View>
                <View style={card.address}>
                  <Text style={card.label}>ที่อยู่</Text>
                  <Text style={[card.text, card.addressText]}>{cardDetail.ADDRESS}</Text>
                </View>
                <View style={card.lastestSection}>
                  <View style={card.date}>
                    <Text style={card.label}>วันออกบัตร</Text>
                    <Text style={card.text}>{this.shortDateFormat(cardDetail.CARD_ISSUE_DATE)}</Text>
                  </View>
                  <View style={card.date}>
                    <Text style={card.label}>วันหมดอายุ</Text>
                    <Text style={card.text}>{this.shortDateFormat(cardDetail.CARD_EXPIRE_DATE)}</Text>
                  </View>
                  <View style={{position: 'absolute', right: 10, bottom: 5}}>
                  <QRCode
                    size={60*this.state.cardRatio}
                    value={this.idFormat(cardDetail.NID)}
                  />
                  </View>
                </View>
              </View>
            </ImageBackground>
          </View>
            <View style={{padding: 15, justifyContent: 'center', alignItems: 'center'}}>
                <TouchableWithoutFeedback onPress={this.closeCard}>
                  <View style={{width: 80, height: 80, borderRadius: 40, backgroundColor: '#BA1F68', justifyContent: 'center', alignItems: 'center'}}>
                    <Text style={{fontSize: 20, color: '#FFFFFF', fontFamily: 'Prompt-Medium'}}>ปิด</Text>
                  </View>
                </TouchableWithoutFeedback>
            </View>
        </View>
      );
    }else{
      const newCard = StyleSheet.create({
        firstSection: {
          flexDirection: 'row',
        }, 
        container: {
          flexDirection: 'column', 
          width: '100%',
          borderRadius: 15, 
        }, 
        profileDetail: {
          flex: 1, 
          flexDirection: 'column', 
          marginLeft: 15*this.state.cardRatio,
        },
        photo: {
          overflow: 'hidden', 
          justifyContent: 'center', 
          alignItems: 'center', 
          width: 80*this.state.cardRatio, 
          height: 96*this.state.cardRatio, 
        }, 
        photoImage: {
          width: 80*this.state.cardRatio, 
          height: 96*this.state.cardRatio, 
        }, 
        header: {
          flexDirection: 'row', 
          justifyContent: 'flex-start', 
          alignItems: 'flex-start',
        },
        title: {
          fontFamily: 'THSarabunNew-Bold', 
          fontSize: 16*this.state.cardRatio,
          marginRight: 5*this.state.cardRatio, 
          marginTop: -5*this.state.cardRatio,
        },
        titleEng: {
          fontFamily: 'THSarabunNew-Bold', 
          fontSize: 12*this.state.cardRatio,
          textAlign: 'center', 
          lineHeight: 12*this.state.cardRatio, 
          color: '#b72b69', 
          marginTop: -2.5*this.state.cardRatio, 
        }, 
        id: {
          fontSize: 14*this.state.cardRatio, 
          fontFamily: 'THSarabunNew-Bold', 
          fontWeight: 'bold', 
        },
        label: {
          marginTop: -5*this.state.cardRatio, 
          fontFamily: 'THSarabunNew-Bold',
          fontSize: 14*this.state.cardRatio, 
        }, 
        eng: {
          color : '#b72b69',
          marginTop: -5*this.state.cardRatio, 
          fontSize: 10*this.state.cardRatio,
        },
        text: {
          marginTop: -5*this.state.cardRatio, 
          fontSize: 12*this.state.cardRatio, 
          fontFamily: 'THSarabunNew-Bold',
          fontWeight: 'bold', 
        }, 
        deform:{
          justifyContent: 'center', 
          alignItems: 'center', 
          marginTop: -18*this.state.cardRatio,
        }, 
        middle: {
          flexDirection: 'row', 
          marginBottom: 5*this.state.cardRatio, 
          marginLeft: 15*this.state.cardRatio,
        },
        middleText: {
          width: '55%', 
        },
        lastestSection: {
          flexDirection: 'row', 
        },
        lastestSectionCol: {
          flex: 0.30*this.state.cardRatio,
          flexDirection: 'column', 
          justifyContent: 'center',
          alignItems: 'center'
        }
      });
  
      cardShow = (
        <View style={{justifyContent:'center', flexDirection: this.state.cardRatio==1 ? 'column' : 'row', alignItems: 'center'}}>
          <View onLayout={this.onLayout} style={{width:this.state.screenWidth}}>
            <ImageBackground source={{uri: 'watermark'}} imageStyle={{borderRadius: 15}} style={{padding: 10*this.state.cardRatio, justifyContent: 'center', alignItems: 'center',}}>
            <View style={[newCard.photo, {position: 'absolute', right: 10}]}>
              <Image style={newCard.photoImage} source={{uri: cardDetail.IMAGE_DATA}} />
            </View>
            <View style={{position: 'absolute', left: -57*this.state.cardRatio, height: 20*this.state.cardRatio, width: 135*this.state.cardRatio, overflow: 'hidden', justifyContent: 'center', transform: [{ rotate: '90deg'}]}} >
              <Barcode value={cardDetail.NID} format='CODE128' height={10} width={1}/>
            </View>
            <View style={newCard.container}>
              <View style={newCard.firstSection}>
                <View style={newCard.profileDetail}>
                  <View style={newCard.header}>
                    <Image source={{uri: 'icon_disabled'}} style={{width: 18.98*this.state.cardRatio, height: 20.33*this.state.cardRatio, marginRight: 5*this.state.cardRatio}} />
                    <Image source={{uri: 'thai_flag'}} style={{width: 22.31*this.state.cardRatio, height: 20.33*this.state.cardRatio, marginRight: 5*this.state.cardRatio}} />
                    <View style={{flexDirection: 'column'}}>
                      <View style={{flexDirection: 'row'}}>
                        <Text style={newCard.title}>บัตรประจำตัวคนพิการ</Text>
                        <View>
                          <Text style={newCard.titleEng}>Thai National Identification Card</Text>
                          <Text style={[newCard.titleEng, {marginTop: -5*this.state.cardRatio}]}>for Persons with Disabilities</Text>
                        </View>
                      </View>
                      <View style={{flexDirection: 'row', marginTop: -5*this.state.cardRatio}}>
                        <View style={{flexDirection: 'column', marginRight: 5*this.state.cardRatio}}>
                          <Text style={newCard.label}>เลขประจำตัวประชาชน</Text>
                          <Text style={[newCard.label, {color: '#b72b69', marginTop: -10*this.state.cardRatio}]}>Identification Number</Text>
                        </View>
                        <Text style={newCard.id}>{this.idFormat(cardDetail.NID, false)}</Text>
                      </View>
                    </View>
                  </View>
                  <Text style={newCard.label}>ชื่อตัวและชื่อสกุล  <Text style={[newCard.text, newCard.name]}>{cardDetail.PERSON_NAME}</Text></Text>
                  <View style={{width: this.state.screenWidth-((80+20+30)*this.state.cardRatio), alignItems: 'center'}}>
                    <View>
                      <Text style={[newCard.label, newCard.eng]}>Name  <Text style={[newCard.text, newCard.eng]}>{this.nameFormat(cardDetail.PERSON_NAME_ENG, 1)}</Text></Text>
                      <Text style={[newCard.label, newCard.eng]}>Last Name  <Text style={[newCard.text, newCard.eng]}>{this.nameFormat(cardDetail.PERSON_NAME_ENG, 2)}</Text></Text>
                      <Text style={newCard.label}>เกิดวันที่  <Text style={newCard.text}>{this.normalDateFormat(cardDetail.BIRTH_DATE)}</Text></Text>
                      <Text style={[newCard.label, newCard.eng]}>Date of Birth  <Text style={[newCard.text, newCard.eng]}>{this.normalDateFormat(cardDetail.BIRTH_DATE, 'en')}</Text></Text>
                    </View>
                  </View>
                </View>
              </View>
              <View style={newCard.middle}>
                <Text style={newCard.label}>ที่อยู่  </Text>
                <Text style={[newCard.text, newCard.middleText]}>{cardDetail.ADDRESS}</Text>
              </View>
              <View style={newCard.middle}>
                <Text style={newCard.label}>ผู้ดูแล  </Text>
                <Text style={[newCard.text, newCard.middleText]}>
                  {this.idFormat(cardDetail.CURATOR_NID, false)}{'\n'}
                  {cardDetail.CURATOR_NAME}
                </Text>
              </View>
              <View style={newCard.lastestSection}>
                <View style={newCard.lastestSectionCol}>
                  <Text style={newCard.text}>{this.shortDateFormat(cardDetail.CARD_ISSUE_DATE)}</Text>
                  <Text style={newCard.label}>วันออกบัตร</Text>
                  <Text style={[newCard.text, newCard.eng]}>{this.shortDateFormat(cardDetail.CARD_ISSUE_DATE, 'en')}</Text>
                  <Text style={[newCard.label, newCard.eng]}>Date of Issue</Text>
                </View>
                <View style={newCard.lastestSectionCol}>
                  <Text style={newCard.text}>{this.shortDateFormat(cardDetail.CARD_EXPIRE_DATE)}</Text>
                  <Text style={newCard.label}>วันหมดอายุ</Text>
                  <Text style={[newCard.text, newCard.eng]}>{this.shortDateFormat(cardDetail.CARD_EXPIRE_DATE, 'en')}</Text>
                  <Text style={[newCard.label, newCard.eng]}>Date of Expiry</Text>
                </View>
                <View style={newCard.lastestSectionCol}>
                  <Text style={newCard.label}>ประเภทความพิการ</Text>
                  <Text style={newCard.text}>{cardDetail.DEFORM_ID}</Text>
                  <Text style={[newCard.label, newCard.eng]}>Type of Disability</Text>
                </View>
              </View>
            </View>
          </ImageBackground>    
          </View>
          <View style={{padding: 15, justifyContent: 'center', alignItems: 'center'}}>
              <TouchableWithoutFeedback onPress={this.closeCard}>
                <View style={{width: 80, height: 80, borderRadius: 40, backgroundColor: '#BA1F68', justifyContent: 'center', alignItems: 'center'}}>
                  <Text style={{fontSize: 20, color: '#FFFFFF', fontFamily: 'Prompt-Medium'}}>ปิด</Text>
                </View>
              </TouchableWithoutFeedback>
            </View>
        </View>
      );
    }

    return(
            <ImageBackground source={{uri: 'background'}} style={{width: '100%', height: '100%'}}>
            <ScrollView>
            <SafeAreaView style={{flex: 1, flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'center', elevation: 2}}>
              <View style={{width: '90%'}}>
                <View style={{backgroundColor: '#FFFFFF', flex: 1, flexDirection: 'column', width: '100%', borderRadius: 15, marginTop: 90}}>
                  <View style={{flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: '#F2F2F2', padding: 10}}>
                    <View style={{position: 'absolute', marginTop: -60, left: 25}}>
                    <View style={{width: 95, height: 95, justifyContent: 'center', alignItems: 'center', backgroundColor: '#FFFFFF', borderRadius: 47.5, overflow: 'hidden'}}>
                        <View style={{width: 89, height: 89, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: '#E3E3E3', borderRadius: 44.5, overflow: 'hidden'}}>
                          <View style={{width: 85, height: 85, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: '#FFFFFF', borderRadius: 42.5, overflow: 'hidden'}}>
                            <Image style={{width: 80, height: 96}} source={{uri: cardDetail.IMAGE_DATA}} />
                          </View>
                        </View>
                      </View>
                      <View style={{position: 'absolute', bottom: 5, right: -20, backgroundColor: '#CE207F', width: 40, height: 40, borderRadius: 20, justifyContent: 'center', alignItems: 'center'}}>
                        <Text style={{color: '#FFFFFF', fontSize: 20, fontFamily: 'Prompt-Medium'}}>{cardDetail.DEFORM_ID}</Text>
                      </View>
                    </View>
                    <Text style={{textAlign: 'center', width: '100%', color: '#CE207F', fontSize: 14, fontFamily: 'Prompt-Medium', paddingLeft: 125}}>{this.idFormat(cardDetail.NID)}</Text>
                  </View>
                  <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingLeft: 30, paddingRight: 30, paddingTop: 15, paddingBottom: 15}}>
                    <View style={{flexDirection: 'column'}}>
                      <View style={{flexDirection: 'row', alignItems: 'center', paddingBottom: 5}}>
                      <View style={{width: 30,  justifyContent: 'flex-start'}}>
                        <Image source={{uri: 'icon_name'}} style={{width: 16.34, height: 10.54}} />
                      </View>
                      <Text style={{color: '#484848', fontSize: 14, fontFamily: 'Prompt-Medium'}}>{cardDetail.PERSON_NAME}</Text>
                    </View>
                      <View style={{flexDirection: 'row', alignItems: 'center'}}>
                      <View style={{width: 30,  justifyContent: 'flex-start'}}>
                        <Image source={{uri: 'icon_birthday'}} style={{width: 12.89, height: 12.89}} />
                      </View>
                      <Text style={{color: '#484848', fontSize: 14, fontFamily: 'Prompt-Medium'}}>{this.normalDateFormat(cardDetail.BIRTH_DATE)}</Text>
                    </View>
                    </View>
                    <View>
                      <QRCode
                        size={60}
                        value={this.idFormat(cardDetail.NID)}
                      />
                    </View>
                  </View>
                  <View style={{flexDirection: 'column', padding: 15, paddingLeft: 20, paddingRight: 20, backgroundColor: '#F7F7F7'}}>
                    <View style={{flexDirection: 'row', alignItems: 'center'}}>
                      <Text style={{color: '#484848', fontSize: 13, fontFamily: 'Prompt-Medium'}}>ประเภทความพิการ ({cardDetail.DEFORM_ID}) {(cardDetail.DEFORM_NAME).replace('ทางการ', '')}</Text>
                    </View>
                  </View>
                  <View style={{flexDirection: 'row', padding: 15, paddingLeft: 20, paddingRight: 20, alignItems: 'center'}}>
                    <View style={{flexDirection: 'column', alignItems: 'flex-start', justifyContent: 'center'}}>
                      <Text style={{color: '#484848', fontSize: 13, fontFamily: 'Prompt-Medium'}}>บัตรหมดอายุ</Text>
                      <Text style={{color: '#484848', fontSize: 13, fontFamily: 'Prompt-Medium'}}>{this.normalDateFormat(cardDetail.CARD_EXPIRE_DATE)}</Text>
                    </View>
                    <View style={{position: 'absolute', right: 20}}>
                    <TouchableOpacity onPress={this.closeCard}>
                      <View style={{flexDirection: 'row', backgroundColor: '#CE207F', justifyContent: 'center', alignItems: 'center' ,padding: 7.5, paddingLeft: 15, paddingRight: 15, borderRadius: 15}}>
                        <Text style={{color: '#FFFFFF', fontSize: 12, fontFamily: 'Prompt-Medium', marginRight: 5}}>กดเพื่อดูบัตรจริง</Text>
                        <Image source={{uri: 'icon_view_card'}} style={{width: 18, height: 13.5}} />
                      </View>
                    </TouchableOpacity>
                    </View>
                  </View>
              </View>
                <Modal isVisible={this.state.isCardVisible}>
                {cardShow}
                </Modal>
                <View style={{flexDirection: 'row', marginTop: 22}}>
                <TouchableOpacity style={{flex: 0.333, backgroundColor: '#E7725C', padding: 8, borderRadius: 15, alignItems: 'center', justifyContent: 'center', elevation: 3,}} onPress={() => { this.props.navigation.navigate('Benefit');}}>
                <View style={{width: '100%', borderWidth: 1, borderColor: 'rgba(255, 255, 255, 0.2)', borderRadius: 15, paddingTop: 10, paddingBottom: 10, alignItems: 'center', justifyContent: 'center'}}>
                  <View style={{height: 34.84,  justifyContent: 'center'}}>
                    <Image source={{uri: 'icon_benefit'}} style={{width: 34.84, height: 34.84}} />
                  </View>
                  <Text style={{color: '#FFFFFF', fontSize: 12, fontFamily: 'Prompt-Medium', marginTop: 8, textAlign: 'center'}}>สิทธิประโยชน์{'\n'}ภาครัฐ</Text>
                </View>
                </TouchableOpacity>
                <TouchableOpacity style={{flex: 0.333, backgroundColor: '#E7725C', padding: 8, marginLeft: 15, marginRight: 15, borderRadius: 15, alignItems: 'center', justifyContent: 'center', elevation: 3,}} onPress={() => { return; }}>
                <View style={{width: '100%', borderWidth: 1, borderColor: 'rgba(255, 255, 255, 0.2)', borderRadius: 15, paddingTop: 10, paddingBottom: 10, alignItems: 'center', justifyContent: 'center'}}>
                  <View style={{height: 34.84,  justifyContent: 'center'}}>
                    <Image source={{uri: 'icon_jobs'}} style={{width: 35.44, height: 31.34}} />
                  </View>
                  <Text style={{color: '#FFFFFF', fontSize: 12, fontFamily: 'Prompt-Medium', marginTop: 8, textAlign: 'center'}}>ค้นหา{'\n'}งาน</Text>
                </View>
                </TouchableOpacity>
                <TouchableOpacity style={{flex: 0.333, backgroundColor: '#E7725C', padding: 8, borderRadius: 15, alignItems: 'center', justifyContent: 'center', elevation: 3,}} onPress={() => { this.props.navigation.navigate('LoanApplication'); }}>
                <View style={{width: '100%', borderWidth: 1, borderColor: 'rgba(255, 255, 255, 0.2)', borderRadius: 15, paddingTop: 10, paddingBottom: 10, alignItems: 'center', justifyContent: 'center'}}>
                  <View style={{height: 34.84,  justifyContent: 'center'}}>
                    <Image source={{uri: 'icon_fund'}} style={{width: 36.47, height: 30.97}} />
                  </View>
                  <Text style={{color: '#FFFFFF', fontSize: 12, fontFamily: 'Prompt-Medium', marginTop: 8, textAlign: 'center'}}>แบบคำขอ{'\n'}กู้ยืมเงิน</Text>
                </View>
                </TouchableOpacity>
              </View>
                <View style={{flexDirection: 'column', marginTop: 22, marginBottom: 22, width: '100%'}}>
                <TouchableOpacity style={{backgroundColor: '#427B8C', padding: 8, borderRadius: 15, alignItems: 'center', elevation: 3,}} onPress={() => {return;}}>
                <View style={{width: '100%', height: 115.61,  borderWidth: 1, borderColor: 'rgba(255, 255, 255, 0.2)', borderRadius: 15, padding: 10, paddingLeft: 20, justifyContent: 'center'}}>
                  <Text style={{color: '#FFFFFF', fontSize: 18, fontFamily: 'Prompt-Medium'}}>คุณคือส่วนหนึ่ง{'\n'}ของสังคม</Text>
                </View>
                <Image source={{uri: 'podium'}} style={{position: 'absolute', bottom: 0, right: 40, width: 150.39, height: 115.61}} />
                </TouchableOpacity>
              </View>
              </View>
            </SafeAreaView>
            </ScrollView>
          </ImageBackground>
    );
  }
}
