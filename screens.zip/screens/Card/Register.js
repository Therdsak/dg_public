import React, { Component } from 'react';
import {ImageBackground, Image, Keyboard, ScrollView, KeyboardAvoidingView, TouchableOpacity, TouchableWithoutFeedback, View, Alert, Text, Dimensions, Platform} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import Spinner from 'react-native-loading-spinner-overlay';
import Icon from 'react-native-vector-icons/AntDesign';
import {TextInputMask} from 'react-native-masked-text';
import {getStatusBarHeight} from 'react-native-iphone-x-helper'
import SimplerDatePicker from '@cawfree/react-native-simpler-date-picker';
import Modal from "react-native-modal";
import moment from 'moment';
import 'moment/locale/th';

export default class CardRegister extends Component {
  constructor(props) {
    super(props);
    this.state = {
      spinner: false, 
      idcard:'',
      isPickerVisible: false,
      date: null, 
      dobText: null,
      dobDate: null,
      sceenWidth:  Math.round(Dimensions.get('window').width)
    };
  }

  doSpinner = (status) =>{
    this.setState({
      spinner: status
    });
  }

  checkIdCard = () =>{

    this.doSpinner(true);
    let idcard = this.state.idcard.replace(/[^0-9]/g, '');
    let birthday = moment(this.state.dobDate).format('DDMM');
    birthday += parseInt(moment(this.state.dobDate).format('YYYY'))+543;
  
    if(idcard.length==0){
      this.doSpinner(false);
      Alert.alert('กรุณากรอกหมายเลขบัตรประชาชน 13 หลัก');
      return;
    }

    if(idcard.length!=13){
      this.doSpinner(false);
      Alert.alert('หมายเลขบัตรประชาชนไม่ถูกต้อง');
      return;
    }

    if(birthday==null){
      this.doSpinner(false);
      Alert.alert('กรุณาระบุวันเกิด');
      return;
    }

    if(birthday.length!=8){
      this.doSpinner(false);
      Alert.alert('วันเกิดไม่ถูกต้อง');
      return;
    }
    
    fetch('https://airthailand.org/porkor/api/',{
      method: 'post', 
      headers: new Headers({
        'Accept': 'application/json',
        'Content-Type':'application/x-www-form-urlencoded',
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHAiOiJwd2QifQ.mdpz_c2m50BMokzp_sR87-gatSC2biOGS5xuNyqJWRo'
      }),
      body: 'idcard='+idcard+'&dob='+birthday.replace(/[^0-9]/g, ''),
    })
      .then((response) => response.json())
      .then((responseJson) => {
        this.doSpinner(false);
        if(responseJson.status===true){
          AsyncStorage.setItem('cardDetail', JSON.stringify(responseJson.result));
          global.cardDetail = responseJson.result;
          this.props.navigation.navigate('DigitalCard');
        }else{
          Alert.alert(responseJson.message);
        }
      })
      .catch((error) =>{
        this.doSpinner(false);
        Alert.alert('บางอย่างผิดพลาด, กรุณาลองใหม่อีกครั้ง');
        console.error(error);
      });
  }

  onDOBDatePicked = (date) => {
    this.setState({
      date: date,
    });
  }
  
  onDOBDateConfirmed = () => {
    moment.locale('th');
    this.setState({
      isPickerVisible: false, 
      dobDate: this.state.date==null  || this.state.date==''?  null : this.state.date,
      dobText: (this.state.date==null || this.state.date=='' ? '' : moment(this.state.date).format('D MMMM ')+(parseInt(moment(this.state.date).format('YYYY'))+543)),
    });
  }

  render() {
    const footerImageWidth = Math.round(Dimensions.get('window').width)>414 ? 414 : Math.round(Dimensions.get('window').width);
    return (
      <ImageBackground source={{uri: 'background'}} style={{width: '100%', height: '100%'}}>
        <ScrollView contentContainerStyle={{flexGrow: 1}}>
          <View style={{flex: 1, flexDirection: 'column', alignItems: 'center', justifyContent: 'space-between'}}>
            <Spinner
              visible={this.state.spinner}
              textStyle={{fontSize: 14, color: '#FFFFFF', fontFamily: 'Prompt-Medium'}}
            />
            <View style={{height: 108, marginTop: 60+getStatusBarHeight(), marginBottom: 25, alignItems: 'center'}}>
                  <Image source={{uri: 'egov_text_logo'}} style={{width: 165, height: 123}}/>
            </View>
            <KeyboardAvoidingView behaviour="padding">
              <View style={{width: '90%', elevation: 2}}>
                <Text style={{color: '#B91E67', fontSize: 20, fontFamily: 'Prompt-Bold', marginBottom: 25, textAlign: "center"}}>ยินดีต้อนรับสู่{'\n'}บัตรประจำตัวดิจิทัลเพื่อคนพิการ</Text>
                <View style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', backgroundColor: '#FFFFFF',borderRadius: 12, marginBottom: 10, shadowColor: "#000", shadowOffset: { width: 0, height: 2,}, shadowOpacity: 0.25, shadowRadius: 5, elevation: 3,}}>
                  <View style={{paddingLeft: 20, paddingRight: 20, borderRightWidth: 1, borderRightColor: '#E8E8E8'}}>
                    <Icon name='idcard' size={18} color="#000000" />
                  </View>
                  <TextInputMask
                    type={'custom'}
                    keyboardType='number-pad'
                    placeholder='กรอกหมายเลขบัตรประชาชน 13 หลัก'
                    options={{
                      mask: '9-9999-99999-99-9'
                    }}
                    value={this.state.idcard}
                    onChangeText={idcard => {
                      this.setState({
                        idcard: idcard
                      })
                    }}
                    placeholderTextColor='#c7c7c7'
                    style={{width: '80%', height: 50, borderWidth: 0, textAlign: 'center', fontSize: 15, fontFamily: 'Prompt-Regular', color: '#000000'}}
                  />
                </View>
                <View style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', backgroundColor: '#FFFFFF', borderRadius: 12, marginBottom: 10, shadowColor: "#000", shadowOffset: { width: 0, height: 2,}, shadowOpacity: 0.25, shadowRadius: 5, elevation: 3,}}>
                  <View style={{paddingLeft: 20, paddingRight: 20, borderRightWidth: 1, borderRightColor: '#E8E8E8'}}>
                    <Icon name='creditcard' size={18} color="#000000" />
                  </View>
                  <TouchableOpacity onPress={()=> {Keyboard.dismiss(); this.setState({ isPickerVisible: true, date: this.state.dobDate==null ? '' : this.state.dobDate })}} style={{width: '80%', height: 50, justifyContent: 'center'}}>
                    <View>
                      <Text style={{textAlign: 'center', fontSize: 15, fontFamily: 'Prompt-Regular', color: this.state.dobText==null || this.state.date=='' ? '#c7c7c7' : '#000000'}}>{this.state.dobText==null || this.state.date=='' ? 'ระบุวันเกิด' : this.state.dobText}</Text>
                    </View>
                  </TouchableOpacity>
                </View>
                <Modal
                isVisible={this.state.isPickerVisible}
                customBackdrop={
                  <TouchableWithoutFeedback onPress={()=>this.setState({ isPickerVisible: false })}>
                    <View style={{ flex: 1, backgroundColor: 'rgba(0, 0, 0, 0.7)'}} />
                  </TouchableWithoutFeedback>
                }>
                  <View style={{backgroundColor: '#FFFFFF', flexDirection: 'column', paddingTop: 10, paddingBottom: 10}}>
                    <Text style={{textAlign: 'center', fontSize: 21, color: '#000000', marginBottom: 10}}>ระบุวันเกิด</Text>
                        <SimplerDatePicker onDatePicked={this.onDOBDatePicked.bind(this)} />
                    <View style={{flexDirection: 'row', justifyContent: 'flex-end'}}>
                    <TouchableOpacity onPress={()=>this.setState({ isPickerVisible: false})}>
                      <Text style={{fontSize: 18, padding: 10}}>ยกเลิก</Text>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={()=>this.onDOBDateConfirmed()}>
                      <Text style={{fontSize: 18, padding: 10, marginRight: 15}}>ตกลง</Text>
                    </TouchableOpacity>
                    </View>
                  </View>
                </Modal>
                <TouchableOpacity style={{alignItems: 'center', justifyContent: 'center', elevation: 3}} onPress={() => {this.checkIdCard()}}>
                  <View style={{backgroundColor: '#B91E67', margin: 15, borderRadius: 15, paddingTop: 10, paddingBottom: 10, paddingLeft: 30, paddingRight: 30}}>
                    <Text style={{color: '#FFFFFF', fontSize: 16, fontFamily: 'Prompt-Bold'}}>เข้าสู่ระบบ</Text>
                  </View>
                </TouchableOpacity>
              </View>
            </KeyboardAvoidingView>
            <View style={{justifyContent: 'flex-start', alignItems: 'center', height: (footerImageWidth*0.617)-71.49, overflow: 'hidden', marginTop: 25}}>
              <Image source={{uri: 'footer_image_2'}} style={{width: footerImageWidth, height: footerImageWidth*0.617}}/>
            </View>
          </View>
        </ScrollView>
      </ImageBackground>
    );
  }
}