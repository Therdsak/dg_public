import React, { Component } from 'react';
import {ScrollView, SafeAreaView, Text, View} from 'react-native';

export default class BenefitDetail extends Component {

    static navigationOptions = ({ navigation }) => ({
        title: typeof(navigation.state.params)==='undefined' || typeof(navigation.state.params.title) === 'undefined' ? 'สิทธิประโยชน์' : navigation.state.params.title,
    });
 
    render()
    {
        return(
            <ScrollView style={{backgroundColor: '#F5F3F6'}}>
                <SafeAreaView  style={{backgroundColor: '#ffffff'}}>
                    <View style={{margin: 20}}>
                        <Text style={{fontSize: 16, fontFamily: 'Prompt-Regular'}}>{this.props.navigation.state.params.detail}</Text>
                    </View>
                </SafeAreaView>
            </ScrollView>
        );
    }
}
