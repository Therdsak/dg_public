import React, { Component } from 'react';
import {Platform, PermissionsAndroid, SafeAreaView, ImageBackground, StyleSheet, ActivityIndicator, View, Dimensions, Text, Linking, TouchableOpacity, TouchableWithoutFeedback} from 'react-native';
import Geolocation from 'react-native-geolocation-service';
import MapView, { PROVIDER_GOOGLE } from 'react-native-maps';
import Icon from 'react-native-vector-icons/FontAwesome5';
import call from 'react-native-phone-call'
import SwipeablePanel from 'rn-swipeable-panel';

const styles = StyleSheet.create({
    map: {
      ...StyleSheet.absoluteFillObject,
    },
});

export default class Location extends Component {

  state = {
    selectionId: 0, 
    locations: [],
    swipeablePanelActive: false, 
    rawLocations: require('../database/locations.json'),
  }

  async componentDidMount() {
    const hasLocationPermission = await this.hasLocationPermission();
    if (hasLocationPermission) {
        Geolocation.getCurrentPosition(
            (position) => {
                this.setState({
                  region: {
                    latitude: position.coords.latitude, 
                    longitude: position.coords.longitude,
                    latitudeDelta: 10,
                    longitudeDelta: 10,
                  }
                });
                for (let i = 0; i <this.state.rawLocations.length; i++) {
                  this.state.rawLocations[i].id = i+1;
                  this.state.rawLocations[i].distance = this.calculateDistance(position.coords.latitude, position.coords.longitude, this.state.rawLocations[i].latitude, this.state.rawLocations[i].longitude);
                }
                this.state.rawLocations.sort(function(a, b) { 
                  return a.distance - b.distance;
                });
                this.setState({
                  locations: this.state.rawLocations,
                  //selectItem: this.state.rawLocations[0]
                });
            },
            (error) => {
              this.setState({
                locations: this.state.rawLocations
              });
                console.log(error.code, error.message);
            },
            { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
        );
    } 
  }

  hasLocationPermission = async () => {
    if (Platform.OS === 'ios' ||
        (Platform.OS === 'android' && Platform.Version < 23)) {
      return true;
    }

    const hasPermission = await PermissionsAndroid.check(
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION
    );

    if (hasPermission) return true;

    const status = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION
    );

    if (status === PermissionsAndroid.RESULTS.GRANTED) return true;

    if (status === PermissionsAndroid.RESULTS.DENIED) {
      ToastAndroid.show('Location permission denied by user.', ToastAndroid.LONG);
    } else if (status === PermissionsAndroid.RESULTS.NEVER_ASK_AGAIN) {
      ToastAndroid.show('Location permission revoked by user.', ToastAndroid.LONG);
    }

    return false;
  }

  calculateDistance = (lat1, lon1, lat2, lon2) => {
    if ((lat1 == lat2) && (lon1 == lon2)) {
      return 0;
    }
    else {
      var radlat1 = Math.PI * lat1/180;
      var radlat2 = Math.PI * lat2/180;
      var theta = lon1-lon2;
      var radtheta = Math.PI * theta/180;
      var dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
      if (dist > 1) {
        dist = 1;
      }
      dist = Math.acos(dist);
      dist = dist * 180/Math.PI;
      dist = dist * 60 * 1.1515;
      dist = dist * 1.609344
      return dist;
    }
  }

  pressMap = (latlon) =>{
    if(latlon.length>0){
      let googleMap = 'https://www.google.co.th/maps/place/'+latlon+'/@'+latlon+',17z';
      Linking.openURL(googleMap)
    }
  }

  pressPhone = (phone) =>{
    if(phone.length>0){
      phone = phone.replace('ต่อ', ',');
      phone = phone.split(',');
      phone = phone[0].replace(/\D/g, '');
      call({
        number: phone,
        prompt: false
      }).catch(console.error);
    }
  }

  pressMail = (mail) =>{
    if(mail.length>0){
      Linking.openURL('mailto:'+mail)
    }
  }
  
  setSelectedList = (location, index) => {
    this.setState({
      selectionId: index, 
      swipeablePanelActive: false, 
      selectItem: location, 
      showAddress: false
    }, () => {
      this.map.fitToSuppliedMarkers(['id-'+index], true);
    });
  };


  openPanel = () => {
      this.setState({ swipeablePanelActive: true });
      setTimeout(function(){
      }, 1000)
  };

  closePanel = () => {
      this.setState({ swipeablePanelActive: false });
  };

  render() {
    if(this.state.locations.lenth>0 && this.state.region){
      return (
        <ImageBackground source={{uri: 'background'}} style={{width: '100%', height: '100%'}}>
        <SafeAreaView style={{flex: 1, flexDirection: 'column', justifyContent: 'center', alignItems: 'center', elevation: 2}}>
          <ActivityIndicator></ActivityIndicator>
        </SafeAreaView>
      </ImageBackground>
      );
    }else{
      const locationList = this.state.locations.map((item, index) => (
          <TouchableWithoutFeedback key={index} onPress={()=>{this.setSelectedList(item, index);}}>
            <View style={{borderTopWidth: index>0 ? 2 : 0, borderTopColor: '#F1F1F1'}}>
              <View style={{flex: 1, width: '100%', flexDirection: 'column', backgroundColor: '#FFFFFF', padding: 15}}>
                <View style={{flexDirection: 'row'}}>
                <View style={{width: '60%'}}>
                  <Text style={{fontFamily: 'Prompt-Medium', color: '#484848', fontSize: 15}}>{item.name}<Text style={{fontFamily: 'Prompt-Medium', color: '#484848', fontSize: 12}}></Text></Text>
                </View>
                <View style={{width: '40%', alignItems: 'flex-end'}}>
                  <Text style={{fontFamily: 'Prompt-Medium', color: '#484848', fontSize: 13}}>ระยะห่าง {item.distance.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")} กม.</Text>
                </View>
              </View>
            </View>
          </View>
          </TouchableWithoutFeedback>
      ));
      return (
            <View style={{flex:1}}>
                <MapView
                ref={ref => {
                  this.map = ref;
                }}
                provider={PROVIDER_GOOGLE}
                style={styles.map}
                showsUserLocation={true}
                initialRegion={this.state.region}
                >
                {this.state.locations.map((item, index) => (
                    <MapView.Marker 
                    key={index}
                    identifier={'id-'+index}
                    coordinate={{
                        latitude: item.latitude,
                        longitude: item.longitude
                    }}
                    onPress={() => this.setState({selectItem: item, showAddress: false})}
                    >
                  </MapView.Marker>
                ))}
                </MapView>
                {this.state.selectItem &&
                    <View>
                      <TouchableWithoutFeedback onPress={() => this.setState({showAddress: !this.state.showAddress})}>
                        <View style={{width: '100%', flexDirection: 'column', backgroundColor: '#CE207F', padding: 15}}>
                          <View style={{flexDirection: 'row'}}>
                            <View style={{width: '60%'}}>
                              <Text style={{fontFamily: 'Prompt-Medium', color: '#FFFFFF', fontSize: 15}}>{this.state.selectItem.name}<Text style={{fontFamily: 'Prompt-Medium', color: '#FFFFFF', fontSize: 12}}> (ระยะห่าง {this.state.selectItem.distance.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")} กม.)</Text></Text>
                            </View>
                            <View style={{flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center', width: '40%'}}>
                              <TouchableOpacity style={{padding: 10}} onPress={() => this.pressMap(this.state.selectItem.latitude+','+this.state.selectItem.longitude)}>
                                <Icon name='directions' size={20} color={this.state.selectItem.latitude.length==0 || this.state.selectItem.longitude.length==0 ? '#F1F1F1' : '#FFFFFF'} />
                              </TouchableOpacity>
                              <TouchableOpacity style={{padding: 10}} onPress={() => this.pressPhone(this.state.selectItem.phone)}>
                                <Icon name='phone' size={20} color={this.state.selectItem.phone.length==0 ? '#F1F1F1' : '#FFFFFF'} />
                              </TouchableOpacity>
                              <TouchableOpacity style={{padding: 10}} onPress={() => this.pressMail(this.state.selectItem.email)}>
                                <Icon name='envelope-open-text' size={20} color={this.state.selectItem.email.length==0 ? '#F1F1F1' : '#FFFFFF'} />
                              </TouchableOpacity>
                            </View>
                          </View>
                        </View>
                      </TouchableWithoutFeedback>
                      <View style={{display: this.state.showAddress ? 'flex' : 'none', width: '100%', padding: 5, backgroundColor: '#F1F1F1'}}>
                      {this.state.selectItem.address.length>0 && (
                      <View style={{flexDirection: 'row', margin: 5}}>
                        <View style={{width: 15, alignItems: 'center'}}><Icon name='directions' size={10} color='#484848' /></View>
                        <Text style={{fontFamily: 'Prompt-Medium', color: '#484848', fontSize: 12, flexWrap: 'wrap', width: '100%'}}> {this.state.selectItem.address}</Text>
                      </View>
                      )}
                      {this.state.selectItem.phone.length>0 && (
                      <TouchableOpacity onPress={() => this.pressPhone(this.state.selectItem.phone)}>
                        <View style={{flexDirection: 'row', margin: 5}}>
                          <View style={{width: 15, alignItems: 'center'}}><Icon name='phone' size={10} color='#484848' /></View>
                          <Text style={{fontFamily: 'Prompt-Medium', color: '#484848', fontSize: 12, flexWrap: 'wrap'}}> {this.state.selectItem.phone}</Text>
                        </View>
                      </TouchableOpacity>
                      )}
                      {this.state.selectItem.fax.length>0 && (
                      <View style={{flexDirection: 'row', margin: 5}}>
                        <View style={{width: 15, alignItems: 'center'}}><Icon name='fax' size={10} color='#484848' /></View>
                        <Text style={{fontFamily: 'Prompt-Medium', color: '#484848', fontSize: 12, flexWrap: 'wrap'}}> {this.state.selectItem.fax}</Text>
                      </View>
                      )}
                      {this.state.selectItem.email.length>0 && (
                      <TouchableOpacity onPress={() => this.pressMail(this.state.selectItem.email)}>
                      <View style={{flexDirection: 'row', margin: 5}}>
                        <View style={{width: 15, alignItems: 'center'}}><Icon name='envelope-open-text' size={10} color='#484848' /></View>
                        <Text style={{fontFamily: 'Prompt-Medium', color: '#484848', fontSize: 12, flexWrap: 'wrap'}}> {this.state.selectItem.email}</Text>
                      </View>
                      </TouchableOpacity>
                      )}
                      </View>
                    </View>
                  }
                <View style={{position: 'absolute', width: '100%', bottom: 30, alignItems: 'center'}}>
                  <TouchableOpacity onPress={()=>{this.openPanel();}}>
                      <View style={{justifyContent: 'center', backgroundColor: '#FFFFFF', width: '100%', paddingLeft: 15, paddingRight: 15, paddingTop: 10, paddingBottom: 10, borderRadius: 15, opacity: 0.8}}>
                        <Text style={{fontFamily: 'Prompt-Medium', color: '#484848', fontSize: 14}}>รายชื่อศูนย์ฯ ทั้งหมด</Text>
                      </View>
                  </TouchableOpacity>
                </View>
                <SwipeablePanel
                    fullWidth
                    closeOnTouchOutside={true}
                    isActive={this.state.swipeablePanelActive}
                    onClose={this.closePanel}
                >
                  <View style={{paddingBottom: Math.round(Dimensions.get('window').height)*0.5}}>
                  {locationList}
                  </View>
                </SwipeablePanel>
            </View>
        )
    }
  }
}
